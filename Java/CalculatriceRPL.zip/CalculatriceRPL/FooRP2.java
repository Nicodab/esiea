public class FooRP2 {
    // Le seul point d'entrée du programme
    // Boucle "infini" dans le mainloop de CalcUI
    public static void main(String [] args){
        new CalcUI(args);
    }
}