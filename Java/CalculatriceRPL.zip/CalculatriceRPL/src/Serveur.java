package src;
import java.net.*;
import java.io.*;

public class Serveur {
    private ServerSocket serverSocket = null;
    
    public Serveur(ServerSocket serveurSocket){
        serverSocket = serveurSocket;
    }
    
}
